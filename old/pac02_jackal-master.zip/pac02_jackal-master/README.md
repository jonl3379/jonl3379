# PAC02_jackal

A custom repository for the PAC02 Jackal robot.  Complete with Zed Stereo camera, Velodyne VLP16, and GPU (low profile GTX 1050) upgrade.